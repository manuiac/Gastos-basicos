# 🧾 Gastos Depto

App web para gestionar los gastos compartidos de un departamento entre dos roomies. Calcula automáticamente quién le debe a quién, con dashboard de gráficos y planificador de compras.

## Instalación

```bash
cd gastos-depto
python3 -m venv venv
source venv/bin/activate        # En Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Ejecución

Hay **dos versiones de la misma app**, comparten backend y base de datos (`gastos.db`):

**Versión Flask (HTML/CSS/JS propio, más control de diseño mobile-first):**
```bash
python app.py
# abrir http://localhost:5000
```

**Versión Streamlit (más rápida de modificar, ideal para iterar):**
```bash
streamlit run streamlit_app.py
# se abre solo en el navegador, normalmente http://localhost:8501
```



## Personalización

Edita `config.py` para cambiar:
- `USER1` / `USER2`: los nombres de los dos integrantes del departamento.
- `CATEGORIES`: las categorías de gasto disponibles.

Para empezar desde cero (sin los datos de ejemplo), simplemente borra el archivo `gastos.db` antes de modificar `seed_data.py`, o comenta la llamada a `seed_data.seed_if_empty()` en `app.py`.

## Estructura del proyecto

```
gastos-depto/
├── app.py              # Rutas Flask (páginas + API JSON)
├── config.py           # Nombres de usuarios, categorías, moneda
├── database.py         # Acceso a SQLite + lógica de cálculo de deudas
├── seed_data.py        # Datos de ejemplo realistas en CLP
├── requirements.txt
├── templates/
│   ├── base.html        # Layout + navegación inferior
│   ├── dashboard.html   # Resumen del mes + gráficos
│   ├── gastos.html      # Registro de gastos
│   ├── liquidacion.html # Cálculo de deudas + historial
│   └── compras.html     # Lista de compras planificadas
└── static/
    ├── css/style.css
    └── js/common.js
```
