// Helpers compartidos por todas las páginas

function formatCLP(amount) {
    return new Intl.NumberFormat('es-CL', {
        style: 'currency',
        currency: 'CLP',
        maximumFractionDigits: 0,
    }).format(amount);
}

const CATEGORY_ICONS = {
    'Cuentas': '💡',
    'Supermercado': '🛒',
    'Limpieza': '🧽',
    'Arriendo': '🏠',
    'Internet': '📶',
    'Otros': '📦',
};

function categoryIcon(cat) {
    return CATEGORY_ICONS[cat] || '📦';
}

function showToast(message) {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 2200);
}

async function apiCall(url, options = {}) {
    const res = await fetch(url, {
        headers: { 'Content-Type': 'application/json' },
        ...options,
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) {
        throw new Error(data.error || 'Ocurrió un error');
    }
    return data;
}
