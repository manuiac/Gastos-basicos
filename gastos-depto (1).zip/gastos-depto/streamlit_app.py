# -*- coding: utf-8 -*-
"""
Versión Streamlit de Gastos Depto.
Reutiliza exactamente el mismo backend que la versión Flask
(config.py, database.py, seed_data.py) -- ambas comparten la
misma base de datos gastos.db.

Ejecutar con:  streamlit run streamlit_app.py
"""
from datetime import date

import pandas as pd
import plotly.express as px
import streamlit as st

import config
import database as db
import seed_data

# ---------------------------------------------------------------------
# Configuración de página + datos iniciales
# ---------------------------------------------------------------------

st.set_page_config(
    page_title="Gastos Depto",
    page_icon="🧾",
    layout="centered",          # columna única, ideal para mobile-first
    initial_sidebar_state="collapsed",
)

db.init_db()
seed_data.seed_if_empty()

MESES_ES = ["", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
            "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]

PALETTE = ["#C98A2C", "#4C7A4F", "#B5482E", "#7A6FB0", "#3E7C9B", "#8A8158"]
CAT_ICON = {"Cuentas": "💡", "Supermercado": "🛒", "Limpieza": "🧽",
            "Arriendo": "🏠", "Internet": "📶", "Otros": "📦"}


def fmt(amount):
    return f"${amount:,.0f}".replace(",", ".")


def nombre_mes(y, m):
    return f"{MESES_ES[m]} {y}"


def shift(y, m, delta):
    total = (y * 12 + (m - 1)) + delta
    return total // 12, total % 12 + 1


# ---------------------------------------------------------------------
# CSS — paleta "boleta de almacén" igual que la versión Flask
# ---------------------------------------------------------------------

st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@500;700;800&family=DM+Sans:wght@400;500;700&display=swap');

html, body, [class*="css"]  { font-family: 'DM Sans', sans-serif; }
.stApp { background-color: #F6F1E4; }
.block-container { padding-top: 1.2rem; padding-bottom: 2rem; max-width: 620px; }

.ticket {
    background: #FFFDF7; border: 1px solid #D9CDAE; border-radius: 14px;
    padding: 20px 18px; margin-bottom: 14px;
    box-shadow: 0 8px 20px -10px rgba(42,37,32,0.25);
}
.eyebrow { font-family: 'JetBrains Mono', monospace; font-size: 11px;
    letter-spacing: 0.12em; text-transform: uppercase; color: #756B5A; }
.balance-amount { font-family: 'JetBrains Mono', monospace; font-weight: 800;
    font-size: 34px; margin: 4px 0; }
.debt { color: #B5482E; } .credit { color: #4C7A4F; } .even { color: #756B5A; }
.stamp { font-family:'JetBrains Mono',monospace; font-weight:800; font-size:11px;
    text-transform:uppercase; padding:4px 10px; border:2px solid currentColor;
    border-radius:6px; float:right; }
hr.tdiv { border:none; border-top:2px dashed #D9CDAE; margin:12px 0; }

div[data-testid="stMetricValue"] { font-family: 'JetBrains Mono', monospace; }

.row-card { background:#FFFDF7; border:1px solid #D9CDAE; border-radius:10px;
    padding:10px 14px; margin-bottom:8px; }

.stButton button { border-radius: 10px; font-weight: 700; }
</style>
""", unsafe_allow_html=True)

# ---------------------------------------------------------------------
# Estado de navegación (mes seleccionado, sección activa)
# ---------------------------------------------------------------------

today = date.today()
if "year" not in st.session_state:
    st.session_state.year, st.session_state.month = today.year, today.month


def month_selector(key_prefix):
    c1, c2, c3 = st.columns([1, 4, 1])
    if c1.button("←", key=f"{key_prefix}_prev", use_container_width=True):
        st.session_state.year, st.session_state.month = shift(
            st.session_state.year, st.session_state.month, -1)
        st.rerun()
    c2.markdown(
        f"<div style='text-align:center;font-family:JetBrains Mono,monospace;"
        f"font-weight:700;padding-top:6px;'>{nombre_mes(st.session_state.year, st.session_state.month)}</div>",
        unsafe_allow_html=True)
    if c3.button("→", key=f"{key_prefix}_next", use_container_width=True):
        st.session_state.year, st.session_state.month = shift(
            st.session_state.year, st.session_state.month, 1)
        st.rerun()


st.markdown("### 🧾 Gastos Depto")
st.caption(f"{config.USER1} & {config.USER2}")

seccion = st.segmented_control(
    "Navegación", ["📊 Dashboard", "🧾 Gastos", "🤝 Liquidación", "🛒 Compras"],
    default="📊 Dashboard", label_visibility="collapsed",
)

# ---------------------------------------------------------------------
# Dialogs (modales) para agregar/editar
# ---------------------------------------------------------------------

@st.dialog("Nuevo gasto")
def dialog_nuevo_gasto():
    description = st.text_input("¿Qué se compró?", placeholder="Ej: Cuenta de la luz")
    c1, c2 = st.columns(2)
    category = c1.selectbox("Categoría", config.CATEGORIES)
    paid_by = c2.selectbox("¿Quién pagó?", [config.USER1, config.USER2])
    c3, c4 = st.columns(2)
    amount = c3.number_input("Monto (CLP)", min_value=0, step=500)
    fecha = c4.date_input("Fecha", value=date.today())

    modo = st.radio("División del gasto", ["50 / 50", "Personalizado"], horizontal=True)
    split1 = 50
    if modo == "Personalizado":
        split1 = st.slider(f"% para {config.USER1}", 0, 100, 50)
    st.caption(f"{config.USER1}: {split1}%  ·  {config.USER2}: {100 - split1}%")

    if st.button("Guardar gasto", type="primary", use_container_width=True):
        if not description or amount <= 0:
            st.error("Completa la descripción y un monto válido.")
        else:
            db.create_expense(description, category, paid_by, fecha.isoformat(),
                               int(amount), split1, 100 - split1)
            st.rerun()


@st.dialog("Agregar a la lista de compras")
def dialog_nueva_compra():
    name = st.text_input("¿Qué necesitan comprar?", placeholder="Ej: Balón de gas")
    c1, c2 = st.columns(2)
    category = c1.selectbox("Categoría", config.CATEGORIES)
    estimated = c2.number_input("Costo estimado (CLP)", min_value=0, step=500)
    if st.button("Agregar a la lista", type="primary", use_container_width=True):
        if not name:
            st.error("Escribe qué necesitan comprar.")
        else:
            db.create_shopping_item(name, category, int(estimated))
            st.rerun()


@st.dialog("Marcar como comprado")
def dialog_marcar_comprado(item):
    st.write(f"**{item['name']}**")
    c1, c2 = st.columns(2)
    real_cost = c1.number_input("Costo real (CLP)", min_value=0,
                                 value=item["estimated_cost"], step=500)
    paid_by = c2.selectbox("¿Quién pagó?", [config.USER1, config.USER2])
    st.caption("Se agregará automáticamente al registro de gastos, dividido 50/50.")
    if st.button("Confirmar compra", type="primary", use_container_width=True):
        db.mark_item_as_bought(item["id"], paid_by, int(real_cost))
        st.rerun()


# ---------------------------------------------------------------------
# Sección: Dashboard
# ---------------------------------------------------------------------

if seccion == "📊 Dashboard":
    month_selector("dash")
    y, m = st.session_state.year, st.session_state.month
    expenses = db.get_expenses(y, m)
    balance = db.calculate_balance(expenses)
    breakdown = db.category_breakdown(expenses)
    py, pm = shift(y, m, -1)
    prev_expenses = db.get_expenses(py, pm)
    prev_breakdown = db.category_breakdown(prev_expenses)
    prev_total = sum(e["amount"] for e in prev_expenses)

    if balance["debtor"]:
        st.markdown(f"""
        <div class="ticket">
            <span class="stamp debt" style="color:#B5482E;">Pendiente</span>
            <div class="eyebrow">Liquidación de {nombre_mes(y, m)}</div>
            <div class="balance-amount debt">{fmt(balance['amount_owed'])}</div>
            <div style="font-size:13px;color:#756B5A;">
                <strong>{balance['debtor']}</strong> le debe a <strong>{balance['creditor']}</strong>
            </div>
        </div>""", unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div class="ticket">
            <span class="stamp" style="color:#4C7A4F;">Al día</span>
            <div class="eyebrow">Liquidación de {nombre_mes(y, m)}</div>
            <div class="balance-amount even">$0</div>
            <div style="font-size:13px;color:#756B5A;">Están al día 🎉</div>
        </div>""", unsafe_allow_html=True)

    c1, c2, c3 = st.columns(3)
    c1.metric(f"{config.USER1} pagó", fmt(balance["paid"].get(config.USER1, 0)))
    c2.metric(f"{config.USER2} pagó", fmt(balance["paid"].get(config.USER2, 0)))
    c3.metric("Total del mes", fmt(balance["total"]))

    st.markdown("##### Gasto por categoría")
    if breakdown:
        df = pd.DataFrame({"Categoría": list(breakdown.keys()),
                            "Monto": list(breakdown.values())})
        fig = px.pie(df, names="Categoría", values="Monto", hole=0.55,
                     color_discrete_sequence=PALETTE)
        fig.update_traces(textinfo="percent+label")
        fig.update_layout(margin=dict(t=10, b=10, l=10, r=10), height=320,
                           paper_bgcolor="rgba(0,0,0,0)")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Aún no hay gastos este mes.")

    st.markdown(f"##### {nombre_mes(y, m)} vs. {nombre_mes(py, pm)}")
    cats = sorted(set(breakdown) | set(prev_breakdown))
    if cats:
        df_comp = pd.DataFrame({
            "Categoría": cats * 2,
            "Monto": [prev_breakdown.get(c, 0) for c in cats] + [breakdown.get(c, 0) for c in cats],
            "Mes": [nombre_mes(py, pm)] * len(cats) + [nombre_mes(y, m)] * len(cats),
        })
        fig2 = px.bar(df_comp, x="Categoría", y="Monto", color="Mes", barmode="group",
                      color_discrete_sequence=["#D9CDAE", "#C98A2C"])
        fig2.update_layout(margin=dict(t=10, b=10, l=10, r=10), height=300,
                            paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                            legend=dict(orientation="h", y=-0.25))
        st.plotly_chart(fig2, use_container_width=True)
        if prev_total > 0:
            diff = (balance["total"] - prev_total) / prev_total * 100
            if diff > 0:
                st.caption(f"📈 Gastaron **{diff:+.0f}%** más que el mes anterior.")
            elif diff < 0:
                st.caption(f"📉 Gastaron **{diff:.0f}%** menos que el mes anterior.")
    else:
        st.info("No hay datos suficientes para comparar todavía.")

# ---------------------------------------------------------------------
# Sección: Gastos
# ---------------------------------------------------------------------

elif seccion == "🧾 Gastos":
    month_selector("gastos")
    if st.button("＋ Agregar gasto", type="primary", use_container_width=True):
        dialog_nuevo_gasto()

    y, m = st.session_state.year, st.session_state.month
    expenses = db.get_expenses(y, m)

    if not expenses:
        st.info(f"No hay gastos registrados en {nombre_mes(y, m)}.")
    for e in expenses:
        c1, c2, c3, c4 = st.columns([0.6, 3.4, 1.6, 0.5])
        c1.markdown(f"<div style='font-size:22px;text-align:center;'>{CAT_ICON.get(e['category'],'📦')}</div>",
                    unsafe_allow_html=True)
        split_note = "" if e["split_user1_pct"] == 50 else f" · {e['split_user1_pct']:.0f}/{e['split_user2_pct']:.0f}"
        c2.markdown(f"**{e['description']}**  \n"
                    f"<span style='font-size:12px;color:#756B5A;'>{e['category']} · {e['date']} · pagó {e['paid_by']}{split_note}</span>",
                    unsafe_allow_html=True)
        c3.markdown(f"<div style='font-family:JetBrains Mono,monospace;font-weight:700;text-align:right;padding-top:6px;'>{fmt(e['amount'])}</div>",
                    unsafe_allow_html=True)
        if c4.button("✕", key=f"del_{e['id']}"):
            db.delete_expense(e["id"])
            st.rerun()
        st.divider()

# ---------------------------------------------------------------------
# Sección: Liquidación
# ---------------------------------------------------------------------

elif seccion == "🤝 Liquidación":
    month_selector("liq")
    y, m = st.session_state.year, st.session_state.month
    expenses = db.get_expenses(y, m)
    balance = db.calculate_balance(expenses)

    if balance["debtor"]:
        st.markdown(f"""
        <div class="ticket">
            <span class="stamp" style="color:#B5482E;">Pendiente</span>
            <div class="eyebrow">¿Quién le debe a quién?</div>
            <div class="balance-amount debt">{fmt(balance['amount_owed'])}</div>
            <div style="font-size:14px;">
                <strong>{balance['debtor']}</strong> le debe a <strong>{balance['creditor']}</strong>
            </div>
            <hr class="tdiv">
        </div>""", unsafe_allow_html=True)
    else:
        st.markdown(f"""
        <div class="ticket">
            <span class="stamp" style="color:#4C7A4F;">Al día</span>
            <div class="eyebrow">¿Quién le debe a quién?</div>
            <div class="balance-amount even">$0</div>
            <div style="font-size:14px;">Cuentas claras, no hay deuda este mes.</div>
        </div>""", unsafe_allow_html=True)

    c1, c2 = st.columns(2)
    c1.metric(f"{config.USER1} pagó", fmt(balance["paid"].get(config.USER1, 0)),
              f"le correspondía {fmt(balance['share'].get(config.USER1, 0))}")
    c2.metric(f"{config.USER2} pagó", fmt(balance["paid"].get(config.USER2, 0)),
              f"le correspondía {fmt(balance['share'].get(config.USER2, 0))}")

    st.markdown("##### Historial de meses")
    months = db.get_available_months()
    if not months:
        st.info("Aún no hay historial.")
    for (hy, hm) in months:
        h_expenses = db.get_expenses(hy, hm)
        h_balance = db.calculate_balance(h_expenses)
        with st.container():
            c1, c2 = st.columns([3, 1])
            estado = (f"{h_balance['debtor']} le debe a {h_balance['creditor']}"
                      if h_balance["debtor"] else "Sin deuda pendiente")
            c1.markdown(f"**📅 {nombre_mes(hy, hm)}**  \n"
                        f"<span style='font-size:12px;color:#756B5A;'>{estado}</span>",
                        unsafe_allow_html=True)
            monto = fmt(h_balance["amount_owed"]) if h_balance["debtor"] else "—"
            c2.markdown(f"<div style='font-family:JetBrains Mono,monospace;font-weight:700;text-align:right;'>{monto}</div>",
                        unsafe_allow_html=True)
            st.divider()

# ---------------------------------------------------------------------
# Sección: Compras
# ---------------------------------------------------------------------

elif seccion == "🛒 Compras":
    items = db.get_shopping_items()
    pendientes = [i for i in items if i["status"] == "pendiente"]
    comprados = [i for i in items if i["status"] == "comprado"]
    total_estimado = sum(i["estimated_cost"] for i in pendientes)

    c1, c2 = st.columns([3, 1])
    c1.metric("Estimado pendiente", fmt(total_estimado))
    c2.metric("Ítems", len(pendientes))

    if st.button("＋ Agregar a la lista", type="primary", use_container_width=True):
        dialog_nueva_compra()

    st.markdown("##### Por comprar")
    if not pendientes:
        st.info("La lista de compras está vacía.")
    for i in pendientes:
        c1, c2, c3, c4 = st.columns([0.5, 3, 1.3, 0.8])
        c1.markdown(f"<div style='font-size:20px;text-align:center;'>{CAT_ICON.get(i['category'],'📦')}</div>",
                    unsafe_allow_html=True)
        c2.markdown(f"**{i['name']}**  \n"
                    f"<span style='font-size:12px;color:#756B5A;'>{i['category']} · estimado {fmt(i['estimated_cost'])}</span>",
                    unsafe_allow_html=True)
        if c3.button("Comprado", key=f"buy_{i['id']}", use_container_width=True):
            dialog_marcar_comprado(i)
        if c4.button("✕", key=f"delc_{i['id']}"):
            db.delete_shopping_item(i["id"])
            st.rerun()
        st.divider()

    if comprados:
        st.markdown("##### Ya comprados")
        for i in comprados:
            st.markdown(f"~~{i['name']}~~  "
                        f"<span style='font-size:12px;color:#756B5A;'>comprado el {i['bought_date']}</span>",
                        unsafe_allow_html=True)
