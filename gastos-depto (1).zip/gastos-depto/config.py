# -*- coding: utf-8 -*-
"""
Configuración general de la aplicación.
Personaliza los nombres de los roomies y las categorías aquí.
"""

# Nombres de los dos integrantes del departamento.
# Cámbialos por los nombres reales de tu roomie y tú.
USER1 = "Tomás"
USER2 = "Javiera"

# Moneda usada en toda la app (CLP = peso chileno, sin decimales)
CURRENCY = "CLP"

# Categorías disponibles para clasificar los gastos
CATEGORIES = [
    "Cuentas",
    "Supermercado",
    "Limpieza",
    "Arriendo",
    "Internet",
    "Otros",
]

# Archivo de la base de datos SQLite (se crea solo la primera vez)
DATABASE = "gastos.db"

# Clave secreta de Flask (usada para mensajes flash, sesiones, etc.)
SECRET_KEY = "cambia-esto-por-algo-secreto-en-produccion"
