# -*- coding: utf-8 -*-
"""
App de gastos compartidos de departamento.
Ejecutar con:  python app.py
Luego abrir:   http://localhost:5000
"""
from datetime import date
import calendar

from flask import Flask, render_template, request, jsonify, redirect, url_for, flash

import config
import database as db
import seed_data

app = Flask(__name__)
app.secret_key = config.SECRET_KEY

MESES_ES = [
    "", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
    "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre",
]


def nombre_mes(year, month):
    return f"{MESES_ES[month]} {year}"


def prev_month(year, month):
    if month == 1:
        return year - 1, 12
    return year, month - 1


def next_month(year, month):
    if month == 12:
        return year + 1, 1
    return year, month + 1


@app.context_processor
def inject_globals():
    return dict(USER1=config.USER1, USER2=config.USER2,
                 CATEGORIES=config.CATEGORIES, CURRENCY=config.CURRENCY)


# ---------------------------------------------------------------------
# Páginas
# ---------------------------------------------------------------------

@app.route("/")
def dashboard():
    today = date.today()
    year = int(request.args.get("year", today.year))
    month = int(request.args.get("month", today.month))

    expenses = db.get_expenses(year, month)
    balance = db.calculate_balance(expenses)
    breakdown = db.category_breakdown(expenses)

    py, pm = prev_month(year, month)
    prev_expenses = db.get_expenses(py, pm)
    prev_total = sum(e["amount"] for e in prev_expenses)

    return render_template(
        "dashboard.html",
        year=year, month=month,
        mes_actual=nombre_mes(year, month),
        mes_anterior=nombre_mes(py, pm),
        balance=balance,
        breakdown=breakdown,
        total=balance["total"],
        prev_total=prev_total,
        cantidad_gastos=len(expenses),
        prev_year=py, prev_month_num=pm,
        next_year=next_month(year, month)[0], next_month_num=next_month(year, month)[1],
    )


@app.route("/gastos")
def gastos():
    today = date.today()
    year = int(request.args.get("year", today.year))
    month = int(request.args.get("month", today.month))
    expenses = db.get_expenses(year, month)
    months = db.get_available_months()
    return render_template(
        "gastos.html",
        expenses=expenses, year=year, month=month,
        mes_actual=nombre_mes(year, month),
        months=[(y, m, nombre_mes(y, m)) for y, m in months],
        today=today.strftime("%Y-%m-%d"),
    )


@app.route("/liquidacion")
def liquidacion():
    today = date.today()
    year = int(request.args.get("year", today.year))
    month = int(request.args.get("month", today.month))

    expenses = db.get_expenses(year, month)
    balance = db.calculate_balance(expenses)

    months = db.get_available_months()
    historial = []
    for y, m in months:
        m_expenses = db.get_expenses(y, m)
        m_balance = db.calculate_balance(m_expenses)
        historial.append(dict(year=y, month=m, nombre=nombre_mes(y, m), balance=m_balance))

    return render_template(
        "liquidacion.html",
        year=year, month=month,
        mes_actual=nombre_mes(year, month),
        balance=balance,
        historial=historial,
        prev_year=prev_month(year, month)[0], prev_month_num=prev_month(year, month)[1],
        next_year=next_month(year, month)[0], next_month_num=next_month(year, month)[1],
    )


@app.route("/compras")
def compras():
    items = db.get_shopping_items()
    pendientes = [i for i in items if i["status"] == "pendiente"]
    comprados = [i for i in items if i["status"] == "comprado"]
    total_estimado = sum(i["estimated_cost"] for i in pendientes)
    return render_template(
        "compras.html",
        pendientes=pendientes, comprados=comprados, total_estimado=total_estimado,
        today=date.today().strftime("%Y-%m-%d"),
    )


# ---------------------------------------------------------------------
# API: Gastos
# ---------------------------------------------------------------------

@app.route("/api/gastos", methods=["POST"])
def api_create_gasto():
    data = request.get_json(force=True)
    try:
        amount = int(data["amount"])
        split1 = float(data.get("split_user1_pct", 50))
        split2 = float(data.get("split_user2_pct", 50))
        if round(split1 + split2) != 100:
            return jsonify(error="Los porcentajes deben sumar 100%"), 400

        new_id = db.create_expense(
            description=data["description"].strip(),
            category=data["category"],
            paid_by=data["paid_by"],
            date=data["date"],
            amount=amount,
            split_user1_pct=split1,
            split_user2_pct=split2,
        )
        return jsonify(id=new_id, ok=True)
    except (KeyError, ValueError) as e:
        return jsonify(error=f"Datos inválidos: {e}"), 400


@app.route("/api/gastos/<int:expense_id>", methods=["DELETE"])
def api_delete_gasto(expense_id):
    db.delete_expense(expense_id)
    return jsonify(ok=True)


# ---------------------------------------------------------------------
# API: Dashboard (datos para gráficos Chart.js)
# ---------------------------------------------------------------------

@app.route("/api/dashboard/<int:year>/<int:month>")
def api_dashboard(year, month):
    expenses = db.get_expenses(year, month)
    breakdown = db.category_breakdown(expenses)

    py, pm = prev_month(year, month)
    prev_expenses = db.get_expenses(py, pm)
    prev_breakdown = db.category_breakdown(prev_expenses)

    categories = sorted(set(list(breakdown.keys()) + list(prev_breakdown.keys())))

    return jsonify(
        categorias=list(breakdown.keys()),
        montos=list(breakdown.values()),
        comparativa=dict(
            categorias=categories,
            mes_actual=[breakdown.get(c, 0) for c in categories],
            mes_anterior=[prev_breakdown.get(c, 0) for c in categories],
        ),
    )


# ---------------------------------------------------------------------
# API: Lista de compras
# ---------------------------------------------------------------------

@app.route("/api/compras", methods=["POST"])
def api_create_compra():
    data = request.get_json(force=True)
    try:
        new_id = db.create_shopping_item(
            name=data["name"].strip(),
            category=data["category"],
            estimated_cost=int(data.get("estimated_cost", 0)),
        )
        return jsonify(id=new_id, ok=True)
    except (KeyError, ValueError) as e:
        return jsonify(error=f"Datos inválidos: {e}"), 400


@app.route("/api/compras/<int:item_id>/comprar", methods=["POST"])
def api_marcar_comprado(item_id):
    data = request.get_json(force=True)
    try:
        split1 = float(data.get("split_user1_pct", 50))
        split2 = float(data.get("split_user2_pct", 50))
        expense_id = db.mark_item_as_bought(
            item_id=item_id,
            paid_by=data["paid_by"],
            real_cost=int(data["real_cost"]),
            split_user1_pct=split1,
            split_user2_pct=split2,
        )
        if expense_id is None:
            return jsonify(error="Ítem no encontrado"), 404
        return jsonify(ok=True, expense_id=expense_id)
    except (KeyError, ValueError) as e:
        return jsonify(error=f"Datos inválidos: {e}"), 400


@app.route("/api/compras/<int:item_id>", methods=["DELETE"])
def api_delete_compra(item_id):
    db.delete_shopping_item(item_id)
    return jsonify(ok=True)


# ---------------------------------------------------------------------

if __name__ == "__main__":
    db.init_db()
    seed_data.seed_if_empty()
    app.run(debug=True, host="0.0.0.0", port=5000)
