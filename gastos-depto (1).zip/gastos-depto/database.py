# -*- coding: utf-8 -*-
"""
Capa de acceso a datos. Usa SQLite (sin dependencias externas) a través
del módulo estándar sqlite3. Mantener esta capa simple hace que el
proyecto se pueda ejecutar con `python app.py` sin instalar una base
de datos aparte.
"""
import sqlite3
from datetime import datetime
from collections import defaultdict

import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    description TEXT NOT NULL,
    category TEXT NOT NULL,
    paid_by TEXT NOT NULL,
    date TEXT NOT NULL,              -- formato YYYY-MM-DD
    amount INTEGER NOT NULL,         -- CLP (entero, sin decimales)
    split_user1_pct REAL NOT NULL DEFAULT 50,
    split_user2_pct REAL NOT NULL DEFAULT 50,
    created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS shopping_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    estimated_cost INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'pendiente',  -- pendiente | comprado
    created_at TEXT NOT NULL,
    bought_date TEXT,
    expense_id INTEGER,
    FOREIGN KEY (expense_id) REFERENCES expenses (id)
);
"""


def get_db():
    conn = sqlite3.connect(config.DATABASE)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    conn = get_db()
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------
# Helpers de gastos
# ---------------------------------------------------------------------

def create_expense(description, category, paid_by, date, amount,
                    split_user1_pct=50, split_user2_pct=50):
    conn = get_db()
    conn.execute(
        """INSERT INTO expenses
           (description, category, paid_by, date, amount,
            split_user1_pct, split_user2_pct, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (description, category, paid_by, date, amount,
         split_user1_pct, split_user2_pct, datetime.now().isoformat()),
    )
    conn.commit()
    new_id = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]
    conn.close()
    return new_id


def delete_expense(expense_id):
    conn = get_db()
    conn.execute("DELETE FROM expenses WHERE id = ?", (expense_id,))
    conn.commit()
    conn.close()


def get_expenses(year=None, month=None):
    """Devuelve gastos, opcionalmente filtrados por año/mes."""
    conn = get_db()
    if year and month:
        prefix = f"{year:04d}-{month:02d}"
        rows = conn.execute(
            "SELECT * FROM expenses WHERE date LIKE ? ORDER BY date DESC, id DESC",
            (f"{prefix}%",),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM expenses ORDER BY date DESC, id DESC"
        ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_available_months():
    """Lista de (año, mes) que tienen gastos registrados, más reciente primero."""
    conn = get_db()
    rows = conn.execute(
        "SELECT DISTINCT substr(date, 1, 7) AS ym FROM expenses ORDER BY ym DESC"
    ).fetchall()
    conn.close()
    result = []
    for r in rows:
        y, m = r["ym"].split("-")
        result.append((int(y), int(m)))
    return result


# ---------------------------------------------------------------------
# Liquidación / cálculo de deudas
# ---------------------------------------------------------------------

def calculate_balance(expenses):
    """
    Calcula cuánto pagó y cuánto le correspondía pagar a cada usuario,
    y devuelve quién le debe a quién.
    """
    paid = {config.USER1: 0, config.USER2: 0}
    share = {config.USER1: 0, config.USER2: 0}

    for e in expenses:
        paid[e["paid_by"]] = paid.get(e["paid_by"], 0) + e["amount"]
        share[config.USER1] += e["amount"] * (e["split_user1_pct"] / 100)
        share[config.USER2] += e["amount"] * (e["split_user2_pct"] / 100)

    balance = {
        config.USER1: round(paid[config.USER1] - share[config.USER1]),
        config.USER2: round(paid[config.USER2] - share[config.USER2]),
    }

    total = sum(e["amount"] for e in expenses)

    debtor, creditor, amount_owed = None, None, 0
    if balance[config.USER1] > balance[config.USER2]:
        creditor, debtor = config.USER1, config.USER2
        amount_owed = abs(balance[config.USER2])
    elif balance[config.USER2] > balance[config.USER1]:
        creditor, debtor = config.USER2, config.USER1
        amount_owed = abs(balance[config.USER1])

    return {
        "paid": paid,
        "share": {k: round(v) for k, v in share.items()},
        "balance": balance,
        "total": total,
        "debtor": debtor,
        "creditor": creditor,
        "amount_owed": round(amount_owed),
    }


def category_breakdown(expenses):
    totals = defaultdict(int)
    for e in expenses:
        totals[e["category"]] += e["amount"]
    # ordenado de mayor a menor
    return dict(sorted(totals.items(), key=lambda kv: kv[1], reverse=True))


# ---------------------------------------------------------------------
# Helpers de lista de compras
# ---------------------------------------------------------------------

def create_shopping_item(name, category, estimated_cost):
    conn = get_db()
    conn.execute(
        """INSERT INTO shopping_items (name, category, estimated_cost, status, created_at)
           VALUES (?, ?, ?, 'pendiente', ?)""",
        (name, category, estimated_cost, datetime.now().isoformat()),
    )
    conn.commit()
    new_id = conn.execute("SELECT last_insert_rowid() AS id").fetchone()["id"]
    conn.close()
    return new_id


def get_shopping_items(status=None):
    conn = get_db()
    if status:
        rows = conn.execute(
            "SELECT * FROM shopping_items WHERE status = ? ORDER BY created_at DESC",
            (status,),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM shopping_items ORDER BY status ASC, created_at DESC"
        ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def mark_item_as_bought(item_id, paid_by, real_cost, split_user1_pct=50, split_user2_pct=50):
    """Marca un ítem de la lista como comprado y crea automáticamente
    el gasto correspondiente en el registro."""
    conn = get_db()
    item = conn.execute(
        "SELECT * FROM shopping_items WHERE id = ?", (item_id,)
    ).fetchone()
    if not item:
        conn.close()
        return None

    today = datetime.now().strftime("%Y-%m-%d")
    expense_id = create_expense(
        description=item["name"],
        category=item["category"],
        paid_by=paid_by,
        date=today,
        amount=real_cost,
        split_user1_pct=split_user1_pct,
        split_user2_pct=split_user2_pct,
    )

    conn.execute(
        """UPDATE shopping_items
           SET status = 'comprado', bought_date = ?, expense_id = ?
           WHERE id = ?""",
        (today, expense_id, item_id),
    )
    conn.commit()
    conn.close()
    return expense_id


def delete_shopping_item(item_id):
    conn = get_db()
    conn.execute("DELETE FROM shopping_items WHERE id = ?", (item_id,))
    conn.commit()
    conn.close()
