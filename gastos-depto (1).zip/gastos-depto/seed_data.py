# -*- coding: utf-8 -*-
"""
Datos de prueba (seed data) realistas para que la app no se vea vacía
la primera vez que se ejecuta. Incluye cuentas básicas y una boleta de
supermercado típica. Los montos están en CLP.
"""
from datetime import date
import calendar

import config
import database as db


def _shift_month(year, month, delta):
    """Devuelve (año, mes) desplazado `delta` meses respecto a year/month."""
    total = (year * 12 + (month - 1)) + delta
    return total // 12, total % 12 + 1


def seed_if_empty():
    """Solo inserta datos de ejemplo si la base de datos está vacía,
    para no duplicar información cada vez que se reinicia la app."""
    if db.get_expenses():
        return

    today = date.today()
    y0, m0 = today.year, today.month          # mes actual
    y1, m1 = _shift_month(y0, m0, -1)          # mes anterior

    def d(year, month, day):
        last_day = calendar.monthrange(year, month)[1]
        day = min(day, last_day)
        return f"{year:04d}-{month:02d}-{day:02d}"

    U1, U2 = config.USER1, config.USER2

    seed_expenses = [
        # --- Mes anterior ---
        dict(description="Cuenta de la luz", category="Cuentas", paid_by=U1,
             date=d(y1, m1, 5), amount=42500, split_user1_pct=50, split_user2_pct=50),
        dict(description="Cuenta del agua", category="Cuentas", paid_by=U2,
             date=d(y1, m1, 7), amount=18300, split_user1_pct=50, split_user2_pct=50),
        dict(description="Internet (WOM Hogar)", category="Internet", paid_by=U1,
             date=d(y1, m1, 10), amount=24990, split_user1_pct=50, split_user2_pct=50),
        dict(description="Boleta supermercado: pan, queso, jamón y probióticos NUP!",
             category="Supermercado", paid_by=U2,
             date=d(y1, m1, 12), amount=23480, split_user1_pct=50, split_user2_pct=50),
        dict(description="Artículos de limpieza (Cif, Poett, esponjas)", category="Limpieza",
             paid_by=U1, date=d(y1, m1, 15), amount=15990, split_user1_pct=50, split_user2_pct=50),
        dict(description="Arriendo del departamento", category="Arriendo", paid_by=U1,
             date=d(y1, m1, 1), amount=420000, split_user1_pct=50, split_user2_pct=50),
        dict(description="Feria: verduras y frutas de la semana", category="Supermercado",
             paid_by=U2, date=d(y1, m1, 20), amount=12500, split_user1_pct=60, split_user2_pct=40),

        # --- Mes actual ---
        dict(description="Cuenta de la luz", category="Cuentas", paid_by=U1,
             date=d(y0, m0, 4), amount=45200, split_user1_pct=50, split_user2_pct=50),
        dict(description="Cuenta del agua", category="Cuentas", paid_by=U2,
             date=d(y0, m0, 6), amount=17850, split_user1_pct=50, split_user2_pct=50),
        dict(description="Internet (WOM Hogar)", category="Internet", paid_by=U1,
             date=d(y0, m0, 10), amount=24990, split_user1_pct=50, split_user2_pct=50),
        dict(description="Boleta supermercado: pan, queso, jamón y probióticos NUP!",
             category="Supermercado", paid_by=U1,
             date=d(y0, m0, 11), amount=26150, split_user1_pct=50, split_user2_pct=50),
        dict(description="Arriendo del departamento", category="Arriendo", paid_by=U1,
             date=d(y0, m0, 1), amount=420000, split_user1_pct=50, split_user2_pct=50),
        dict(description="Detergente y papel higiénico", category="Limpieza", paid_by=U2,
             date=d(y0, m0, 14), amount=11200, split_user1_pct=50, split_user2_pct=50),
    ]

    for e in seed_expenses:
        db.create_expense(**e)

    # Lista de compras pendientes / ya compradas, como ejemplo
    pending = [
        dict(name="Balón de gas (cambio)", category="Cuentas", estimated_cost=16000),
        dict(name="Bombillas LED para el pasillo", category="Limpieza", estimated_cost=6500),
        dict(name="Café en grano 1kg", category="Supermercado", estimated_cost=9990),
    ]
    for item in pending:
        db.create_shopping_item(**item)
